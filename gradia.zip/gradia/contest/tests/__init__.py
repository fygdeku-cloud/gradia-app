# Tests for gradia.contest
