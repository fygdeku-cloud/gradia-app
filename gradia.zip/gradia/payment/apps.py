from django.apps import AppConfig


class PaymentConfig(AppConfig):
    name = 'gradia.payment'
